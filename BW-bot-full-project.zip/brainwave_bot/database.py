from __future__ import annotations

import sqlite3
from pathlib import Path


def ensure_database(database: Path, seed_file: Path | None = None) -> Path:
    """Create the demonstration SQLite database from its versioned SQL seed when absent."""
    if database.exists():
        return database
    seed_file = seed_file or database.with_name("seed.sql")
    if not seed_file.exists():
        raise FileNotFoundError(f"Database and seed file are missing: {database}, {seed_file}")
    database.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(database) as connection:
        connection.executescript(seed_file.read_text(encoding="utf-8"))
    return database
