CREATE TABLE stories (
    story_id INTEGER PRIMARY KEY,
    story_title TEXT NOT NULL,
    market TEXT NOT NULL,
    category TEXT NOT NULL,
    submission_date TEXT NOT NULL,
    status TEXT NOT NULL,
    submitter TEXT NOT NULL,
    revenue REAL NOT NULL
);

INSERT INTO stories VALUES
(1, 'AI Transformation', 'EMIA', 'AI', '2025-05-10', 'Submitted', 'John', 150000),
(2, 'Cloud Migration', 'EMIA', 'Cloud', '2025-07-15', 'Submitted', 'Sarah', 250000),
(3, 'Data Modernization', 'APAC', 'Data', '2025-08-20', 'Submitted', 'David', 180000),
(4, 'GenAI Assistant', 'EMIA', 'GenAI', '2026-02-10', 'Submitted', 'Emma', 320000),
(5, 'Retail Analytics', 'APAC', 'Analytics', '2026-06-12', 'Submitted', 'Alex', 210000),
(6, 'Supply-chain Vision', 'AMER', 'AI', '2026-04-22', 'Submitted', 'Priya', 400000),
(7, 'Contact Centre Copilot', 'EMIA', 'GenAI', '2026-08-03', 'Draft', 'Mina', 95000),
(8, 'Banking Lakehouse', 'EMIA', 'Data', '2026-08-28', 'Submitted', 'Omar', 275000),
(9, 'Commerce Platform', 'LATAM', 'Cloud', '2025-12-01', 'Submitted', 'Luis', 135000);
