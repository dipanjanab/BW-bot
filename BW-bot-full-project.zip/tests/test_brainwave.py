from datetime import date
from pathlib import Path
import pytest
from brainwave_bot.context import BusinessContextResolver
from brainwave_bot.models import Route, SQLStatement
from brainwave_bot.orchestrator import BrainwaveOrchestrator, MarketAuthorizationError
from brainwave_bot.sql_tool import SQLValidationError, SQLValidator

ROOT = Path(__file__).resolve().parents[1]

@pytest.fixture(scope="module")
def bot() -> BrainwaveOrchestrator:
    return BrainwaveOrchestrator(ROOT / "data" / "brainwave.db", ROOT / "knowledge")

def test_resolves_business_terms_and_fy26():
    value = BusinessContextResolver().resolve("How many EMIA stories were submitted in FY26?")
    assert value.market == "EMEA" and value.database_market == "EMIA"
    assert value.start_date == "2025-04-01" and value.end_date == "2026-03-31"
    assert "submissions" in value.normalized

def test_current_year_uses_april_march_fiscal_calendar():
    value = BusinessContextResolver().resolve("Show submissions this year", date(2026, 9, 8))
    assert (value.fiscal_label, value.start_date, value.end_date) == ("FY27", "2026-04-01", "2027-03-31")

def test_orchestrator_routes_sql_rag_and_hybrid():
    resolver = BusinessContextResolver()
    assert resolver.resolve("How many submissions?").route == Route.SQL
    assert resolver.resolve("What does EMIA mean?").route == Route.RAG
    assert resolver.resolve("How many submissions and explain the definition?").route == Route.HYBRID

def test_rag_retrieves_supplied_market_context(bot):
    result = bot.ask("What does EMIA mean?")
    assert result.route == Route.RAG
    assert any("Europe, Middle East, India and Africa" in item for item in result.context)

def test_sql_is_parameterized_and_returns_actual_fy26_result(bot):
    result = bot.ask("How many EMIA stories were submitted in FY26?")
    assert result.rows == [{"submission_count": 3}]
    assert ":market" in result.sql and "EMIA" not in result.sql
    assert result.parameters["market"] == "EMIA"
    assert result.context[0].startswith("[market_definitions.md]")

def test_sqlglot_rejects_non_allowlisted_table():
    statement = SQLStatement(sql="SELECT * FROM secrets", parameters={})
    with pytest.raises(SQLValidationError):
        SQLValidator({"stories"}).validate(statement)

def test_market_authorization_blocks_and_filters(bot):
    with pytest.raises(MarketAuthorizationError):
        bot.ask("How many EMIA submissions in FY26?", ["APAC"])
    grouped = bot.ask("Show submissions by market in FY26", ["APAC"])
    assert grouped.rows == [{"market": "APAC", "submission_count": 1}]
